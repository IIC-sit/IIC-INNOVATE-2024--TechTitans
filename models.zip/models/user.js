const mongoose = require('mongoose');

// Connect to MongoDB (you can change the URL if necessary)
mongoose.connect('mongodb://localhost:27017/mydatabase', { useNewUrlParser: true, useUnifiedTopology: true });

// Define a schema for the data (structure of the documents)
const userSchema = new mongoose.Schema({
  name: String,
  age: Number,
  email: String,
  address: {
    street: String,
    city: String,
    state: String,
    zip: String
  }
});

// Create a model based on the schema
const User = mongoose.model('User', userSchema);